# App1 aprender ingles

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.2.0.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`.
The app will automatically reload if you change any of the source files.

Projeto desenvolvido com angular cli versão 10
Clone o repositorio e nicie o diretorio app1  no terminal usando o comando npm i
após iniciar suba o servidor com ng s -o
   
  
