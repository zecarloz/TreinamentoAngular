import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-func-get',
  templateUrl: './func-get.component.html',
  styleUrls: ['./func-get.component.css']
})
export class FuncGetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
