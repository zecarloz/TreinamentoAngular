import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-func-add',
  templateUrl: './func-add.component.html',
  styleUrls: ['./func-add.component.css']
})
export class FuncAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
