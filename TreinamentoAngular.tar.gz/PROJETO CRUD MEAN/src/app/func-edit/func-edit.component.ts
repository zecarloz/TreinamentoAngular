import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-func-edit',
  templateUrl: './func-edit.component.html',
  styleUrls: ['./func-edit.component.css']
})
export class FuncEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
